<?php
/**
 * Grander ACF Field Groups Registration
 *
 * Registers all ACF field groups programmatically.
 * All groups have show_in_rest enabled for REST API compatibility.
 *
 * Field naming convention: gc_[context]_[field_name]
 * All field names match grander_acf_field_map_v1.csv
 *
 * @package Grander_Core
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Grander_ACF
 */
class Grander_ACF {

    /**
     * Single instance
     *
     * @var Grander_ACF
     */
    private static $instance = null;

    /**
     * Get instance
     *
     * @return Grander_ACF
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Register ACF options page
        add_action( 'acf/init', array( $this, 'register_options_page' ) );

        // Register field groups
        add_action( 'acf/init', array( $this, 'register_field_groups' ) );

        // Enable REST API for ACF
        add_filter( 'acf/rest/enabled', '__return_true' );
    }

    /**
     * Register ACF Options Page
     */
    public function register_options_page() {
        if ( function_exists( 'acf_add_options_page' ) ) {
            acf_add_options_page( array(
                'page_title'    => 'Grander Site Settings',
                'menu_title'    => 'Grander Settings',
                'menu_slug'     => 'grander-settings',
                'capability'    => 'manage_options',
                'redirect'      => false,
                'icon_url'      => 'dashicons-admin-home',
                'position'      => 3,
            ) );
        }
    }

    /**
     * Register all field groups
     */
    public function register_field_groups() {
        if ( ! function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }

        $this->register_global_options();
        $this->register_page_hero_fields();
        $this->register_home_fields();
        $this->register_service_fields();
        $this->register_process_fields();
        $this->register_team_fields();
        $this->register_gallery_fields();
        $this->register_contact_fields();
        $this->register_estimate_fields();
        $this->register_project_fields();
        $this->register_faq_fields();
        $this->register_testimonial_fields();
    }

    /**
     * Global Options Fields
     *
     * Location: Options page
     * Contains: Announcement bar, service area, phone, footer logos, social URLs,
     *           trust bar, events, featured projects, estimate form shortcode
     */
    private function register_global_options() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_global_options',
            'title' => 'Global Site Settings',
            'fields' => array(

                // =============================================================
                // ANNOUNCEMENT BAR TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_announcement',
                    'label' => 'Announcement Bar',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_announcement_enabled',
                    'label' => 'Enable Announcement Bar',
                    'name' => 'gc_announcement_enabled',
                    'type' => 'true_false',
                    'default_value' => 0,
                    'ui' => 1,
                ),
                array(
                    'key' => 'field_gc_announcement_message',
                    'label' => 'Announcement Message',
                    'name' => 'gc_announcement_message',
                    'type' => 'textarea',
                    'rows' => 2,
                    'instructions' => 'Short message, sentence case. Keep it brief.',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_announcement_enabled',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                ),
                array(
                    'key' => 'field_gc_announcement_button_label',
                    'label' => 'Button Label',
                    'name' => 'gc_announcement_button_label',
                    'type' => 'text',
                    'instructions' => 'Optional. Leave blank for no button.',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_announcement_enabled',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                ),
                array(
                    'key' => 'field_gc_announcement_button_url',
                    'label' => 'Button URL',
                    'name' => 'gc_announcement_button_url',
                    'type' => 'url',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_announcement_enabled',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                ),
                array(
                    'key' => 'field_gc_announcement_style',
                    'label' => 'Announcement Style',
                    'name' => 'gc_announcement_style',
                    'type' => 'select',
                    'choices' => array(
                        'info' => 'Info (neutral)',
                        'highlight' => 'Highlight (brand gold)',
                        'urgent' => 'Urgent (attention)',
                    ),
                    'default_value' => 'info',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_announcement_enabled',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                ),

                // =============================================================
                // SERVICE AREA TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_service_area',
                    'label' => 'Service Area',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_service_area_enabled',
                    'label' => 'Enable Service Area Line',
                    'name' => 'gc_service_area_enabled',
                    'type' => 'true_false',
                    'default_value' => 1,
                    'ui' => 1,
                ),
                array(
                    'key' => 'field_gc_service_area_text',
                    'label' => 'Service Area Text',
                    'name' => 'gc_service_area_text',
                    'type' => 'text',
                    'default_value' => 'Proudly serving the Upstate of South Carolina with custom homes and outdoor living.',
                    'instructions' => 'Microline displayed in footer and near CTAs.',
                ),

                // =============================================================
                // HEADER & CONTACT TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_header',
                    'label' => 'Header & Contact',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_phone_number',
                    'label' => 'Phone Number',
                    'name' => 'gc_phone_number',
                    'type' => 'text',
                    'instructions' => 'Used for header Call Now button and mobile floating icon.',
                ),
                array(
                    'key' => 'field_gc_header_estimate_label',
                    'label' => 'Estimate Button Label',
                    'name' => 'gc_header_estimate_label',
                    'type' => 'text',
                    'default_value' => 'Request an estimate',
                ),
                array(
                    'key' => 'field_gc_header_estimate_mode',
                    'label' => 'Estimate Button Mode',
                    'name' => 'gc_header_estimate_mode',
                    'type' => 'select',
                    'choices' => array(
                        'lightbox' => 'Open Lightbox',
                        'link' => 'Link to Page',
                    ),
                    'default_value' => 'lightbox',
                ),
                array(
                    'key' => 'field_gc_header_estimate_url',
                    'label' => 'Estimate Page URL',
                    'name' => 'gc_header_estimate_url',
                    'type' => 'url',
                    'instructions' => 'Used if mode is Link.',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_header_estimate_mode',
                                'operator' => '==',
                                'value' => 'link',
                            ),
                        ),
                    ),
                ),

                // =============================================================
                // FOOTER TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_footer',
                    'label' => 'Footer',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_footer_logo_white',
                    'label' => 'Footer Logo (White)',
                    'name' => 'gc_footer_logo_white',
                    'type' => 'image',
                    'return_format' => 'array',
                    'preview_size' => 'medium',
                    'instructions' => 'White version of logo for dark footer background. SVG or PNG.',
                ),
                array(
                    'key' => 'field_gc_footer_hba_logo',
                    'label' => 'Home Builders Association Logo',
                    'name' => 'gc_footer_hba_logo',
                    'type' => 'image',
                    'return_format' => 'array',
                    'preview_size' => 'thumbnail',
                ),
                array(
                    'key' => 'field_gc_footer_hba_url',
                    'label' => 'HBA URL',
                    'name' => 'gc_footer_hba_url',
                    'type' => 'url',
                ),
                array(
                    'key' => 'field_gc_footer_bbb_logo',
                    'label' => 'Better Business Bureau Logo',
                    'name' => 'gc_footer_bbb_logo',
                    'type' => 'image',
                    'return_format' => 'array',
                    'preview_size' => 'thumbnail',
                ),
                array(
                    'key' => 'field_gc_footer_bbb_url',
                    'label' => 'BBB URL',
                    'name' => 'gc_footer_bbb_url',
                    'type' => 'url',
                ),

                // =============================================================
                // SOCIAL TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_social',
                    'label' => 'Social',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_social_instagram_url',
                    'label' => 'Instagram URL',
                    'name' => 'gc_social_instagram_url',
                    'type' => 'url',
                ),
                array(
                    'key' => 'field_gc_social_facebook_url',
                    'label' => 'Facebook URL',
                    'name' => 'gc_social_facebook_url',
                    'type' => 'url',
                ),

                // =============================================================
                // TRUST BAR TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_trust',
                    'label' => 'Trust Bar',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_trust_items',
                    'label' => 'Trust Bar Items',
                    'name' => 'gc_trust_items',
                    'type' => 'repeater',
                    'max' => 5,
                    'layout' => 'block',
                    'button_label' => 'Add Trust Item',
                    'sub_fields' => array(
                        array(
                            'key' => 'field_gc_trust_items__logo',
                            'label' => 'Logo/Icon',
                            'name' => 'logo',
                            'type' => 'image',
                            'return_format' => 'array',
                            'preview_size' => 'thumbnail',
                            'wrapper' => array( 'width' => '25' ),
                        ),
                        array(
                            'key' => 'field_gc_trust_items__label',
                            'label' => 'Label',
                            'name' => 'label',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '30' ),
                        ),
                        array(
                            'key' => 'field_gc_trust_items__url',
                            'label' => 'URL (optional)',
                            'name' => 'url',
                            'type' => 'url',
                            'wrapper' => array( 'width' => '30' ),
                        ),
                        array(
                            'key' => 'field_gc_trust_items__order',
                            'label' => 'Order',
                            'name' => 'order',
                            'type' => 'number',
                            'instructions' => 'Optional. Use to manually sort items.',
                            'wrapper' => array( 'width' => '15' ),
                        ),
                    ),
                ),

                // =============================================================
                // EVENTS TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_events',
                    'label' => 'Events',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_events_enabled',
                    'label' => 'Enable Events Strip',
                    'name' => 'gc_events_enabled',
                    'type' => 'true_false',
                    'default_value' => 0,
                    'ui' => 1,
                    'instructions' => 'Toggle the events strip on Home and Contact pages. Disabled by default for launch.',
                ),
                array(
                    'key' => 'field_gc_events',
                    'label' => 'Upcoming Events',
                    'name' => 'gc_events',
                    'type' => 'repeater',
                    'layout' => 'block',
                    'button_label' => 'Add Event',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_events_enabled',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                    'sub_fields' => array(
                        array(
                            'key' => 'field_gc_events__title',
                            'label' => 'Event Title',
                            'name' => 'title',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_events__location',
                            'label' => 'Location',
                            'name' => 'location',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_events__short_summary',
                            'label' => 'Short Summary',
                            'name' => 'short_summary',
                            'type' => 'textarea',
                            'rows' => 2,
                        ),
                        array(
                            'key' => 'field_gc_events__start_date',
                            'label' => 'Start Date',
                            'name' => 'start_date',
                            'type' => 'date_picker',
                            'display_format' => 'F j, Y',
                            'return_format' => 'Y-m-d',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_events__end_date',
                            'label' => 'End Date (optional)',
                            'name' => 'end_date',
                            'type' => 'date_picker',
                            'display_format' => 'F j, Y',
                            'return_format' => 'Y-m-d',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_events__button_label',
                            'label' => 'Button Label',
                            'name' => 'button_label',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_events__button_url',
                            'label' => 'Button URL',
                            'name' => 'button_url',
                            'type' => 'url',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                    ),
                ),

                // =============================================================
                // FEATURED PROJECTS TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_featured_projects',
                    'label' => 'Featured Projects',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_featured_projects_enabled',
                    'label' => 'Enable Featured Projects',
                    'name' => 'gc_featured_projects_enabled',
                    'type' => 'true_false',
                    'default_value' => 1,
                    'ui' => 1,
                ),
                array(
                    'key' => 'field_gc_featured_projects',
                    'label' => 'Featured Projects',
                    'name' => 'gc_featured_projects',
                    'type' => 'relationship',
                    'post_type' => array( 'project' ),
                    'filters' => array( 'search', 'taxonomy' ),
                    'return_format' => 'id',
                    'min' => 0,
                    'max' => 6,
                    'instructions' => 'Select 3-6 projects to feature on Home page.',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_featured_projects_enabled',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                ),

                // =============================================================
                // ESTIMATE FORM TAB
                // =============================================================
                array(
                    'key' => 'field_gc_tab_estimate_form',
                    'label' => 'Estimate Form',
                    'type' => 'tab',
                ),
                array(
                    'key' => 'field_gc_estimate_form_shortcode',
                    'label' => 'Gravity Forms Shortcode',
                    'name' => 'gc_estimate_form_shortcode',
                    'type' => 'text',
                    'instructions' => 'Paste the Gravity Forms shortcode here. Example: [gravityform id="1" title="false" description="false"]',
                    'placeholder' => '[gravityform id="1" title="false" description="false"]',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'options_page',
                        'operator' => '==',
                        'value' => 'grander-settings',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Page Hero Fields
     *
     * Location: All pages
     * Contains: Hero headline, subline, background image, nav variant, trust bar toggle
     */
    private function register_page_hero_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_page_hero',
            'title' => 'Page Hero Settings',
            'fields' => array(
                array(
                    'key' => 'field_gc_hero_headline',
                    'label' => 'Hero Headline',
                    'name' => 'gc_hero_headline',
                    'type' => 'text',
                    'instructions' => 'Main headline displayed in the hero section.',
                ),
                array(
                    'key' => 'field_gc_hero_subline',
                    'label' => 'Hero Subline',
                    'name' => 'gc_hero_subline',
                    'type' => 'textarea',
                    'rows' => 2,
                    'instructions' => 'Supporting text below the headline.',
                ),
                array(
                    'key' => 'field_gc_hero_background_image',
                    'label' => 'Hero Background Image',
                    'name' => 'gc_hero_background_image',
                    'type' => 'image',
                    'return_format' => 'array',
                    'preview_size' => 'medium',
                ),
                array(
                    'key' => 'field_gc_hero_nav_variant',
                    'label' => 'Navigation Color Variant',
                    'name' => 'gc_hero_nav_variant',
                    'type' => 'select',
                    'choices' => array(
                        'light' => 'Light (for dark backgrounds)',
                        'dark' => 'Dark (for light backgrounds)',
                    ),
                    'default_value' => 'light',
                    'instructions' => 'Choose text color for overlay navigation based on hero image brightness.',
                ),
                array(
                    'key' => 'field_gc_trust_bar_enabled_on_page',
                    'label' => 'Show Trust Bar on This Page',
                    'name' => 'gc_trust_bar_enabled_on_page',
                    'type' => 'true_false',
                    'default_value' => 0,
                    'ui' => 1,
                    'instructions' => 'Display the trust bar below the hero on this page.',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'page',
                    ),
                ),
            ),
            'position' => 'acf_after_title',
            'show_in_rest' => true,
        ) );
    }

    /**
     * Home Page Fields
     *
     * Location: Home page (front page)
     * Contains: Expert offerings intro, performance teaser, testimonial variant
     */
    private function register_home_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_home_fields',
            'title' => 'Home Page Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_home_expert_offerings_intro',
                    'label' => 'Expert Offerings Intro',
                    'name' => 'gc_home_expert_offerings_intro',
                    'type' => 'textarea',
                    'rows' => 4,
                    'instructions' => 'Introductory paragraph above the service cards.',
                ),
                array(
                    'key' => 'field_gc_home_performance_teaser_headline',
                    'label' => 'Performance Teaser Headline',
                    'name' => 'gc_home_performance_teaser_headline',
                    'type' => 'text',
                ),
                array(
                    'key' => 'field_gc_home_performance_teaser_body',
                    'label' => 'Performance Teaser Body',
                    'name' => 'gc_home_performance_teaser_body',
                    'type' => 'textarea',
                    'rows' => 4,
                ),
                array(
                    'key' => 'field_gc_home_testimonial_slider_variant',
                    'label' => 'Testimonial Slider Variant',
                    'name' => 'gc_home_testimonial_slider_variant',
                    'type' => 'select',
                    'choices' => array(
                        'v1' => 'Version 1 (Standard)',
                        'v2' => 'Version 2 (Compact)',
                    ),
                    'default_value' => 'v1',
                    'instructions' => 'Choose which testimonial slider design to use.',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page_type',
                        'operator' => '==',
                        'value' => 'front_page',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Service Page Fields
     *
     * Location: Service pages (using page template or specific pages)
     * Contains: Overview, jump links toggle, portfolio sections, mid CTA, FAQ groups
     */
    private function register_service_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_service_fields',
            'title' => 'Service Page Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_service_overview',
                    'label' => 'Service Overview',
                    'name' => 'gc_service_overview',
                    'type' => 'textarea',
                    'rows' => 5,
                    'instructions' => '120-180 words describing this service category.',
                ),
                array(
                    'key' => 'field_gc_service_jump_links_enabled',
                    'label' => 'Enable Jump Links',
                    'name' => 'gc_service_jump_links_enabled',
                    'type' => 'true_false',
                    'default_value' => 1,
                    'ui' => 1,
                ),
                array(
                    'key' => 'field_gc_service_featured_projects',
                    'label' => 'Featured Projects (Override)',
                    'name' => 'gc_service_featured_projects',
                    'type' => 'relationship',
                    'post_type' => array( 'project' ),
                    'filters' => array( 'search', 'taxonomy' ),
                    'return_format' => 'id',
                    'instructions' => 'Optional. Override global featured projects for this service page.',
                ),

                // Portfolio Sections Repeater
                array(
                    'key' => 'field_gc_service_portfolio_sections',
                    'label' => 'Project Portfolio Sections',
                    'name' => 'gc_service_portfolio_sections',
                    'type' => 'repeater',
                    'layout' => 'block',
                    'button_label' => 'Add Project Section',
                    'instructions' => 'Add project showcase sections. Newest projects should be first.',
                    'sub_fields' => array(
                        array(
                            'key' => 'field_gc_service_portfolio_sections__title',
                            'label' => 'Project Title',
                            'name' => 'title',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_service_portfolio_sections__location',
                            'label' => 'Location',
                            'name' => 'location',
                            'type' => 'text',
                            'placeholder' => 'City, SC',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_service_portfolio_sections__summary',
                            'label' => 'Project Summary',
                            'name' => 'summary',
                            'type' => 'textarea',
                            'rows' => 3,
                        ),
                        array(
                            'key' => 'field_gc_service_portfolio_sections__has_design_image',
                            'label' => 'Include Design/Before Image',
                            'name' => 'has_design_image',
                            'type' => 'true_false',
                            'default_value' => 0,
                            'ui' => 1,
                            'instructions' => 'Toggle to show a design rendering or before photo.',
                        ),
                        array(
                            'key' => 'field_gc_service_portfolio_sections__design_image',
                            'label' => 'Design/Before Image',
                            'name' => 'design_image',
                            'type' => 'image',
                            'return_format' => 'array',
                            'preview_size' => 'medium',
                            'conditional_logic' => array(
                                array(
                                    array(
                                        'field' => 'field_gc_service_portfolio_sections__has_design_image',
                                        'operator' => '==',
                                        'value' => '1',
                                    ),
                                ),
                            ),
                        ),
                        array(
                            'key' => 'field_gc_service_portfolio_sections__gallery',
                            'label' => 'Project Gallery',
                            'name' => 'gallery',
                            'type' => 'gallery',
                            'return_format' => 'array',
                            'preview_size' => 'medium',
                        ),
                    ),
                ),

                // Mid-page CTA
                array(
                    'key' => 'field_gc_service_mid_cta_headline',
                    'label' => 'Mid-Page CTA Headline',
                    'name' => 'gc_service_mid_cta_headline',
                    'type' => 'text',
                    'default_value' => 'Ready to start your project?',
                ),
                array(
                    'key' => 'field_gc_service_mid_cta_body',
                    'label' => 'Mid-Page CTA Body',
                    'name' => 'gc_service_mid_cta_body',
                    'type' => 'textarea',
                    'rows' => 2,
                ),
                array(
                    'key' => 'field_gc_service_estimate_cta_label',
                    'label' => 'Estimate CTA Button Label',
                    'name' => 'gc_service_estimate_cta_label',
                    'type' => 'text',
                    'default_value' => 'Request an estimate',
                ),

                // FAQ Groups
                array(
                    'key' => 'field_gc_service_faq_groups',
                    'label' => 'FAQ Groups to Display',
                    'name' => 'gc_service_faq_groups',
                    'type' => 'taxonomy',
                    'taxonomy' => 'faq_group',
                    'field_type' => 'multi_select',
                    'return_format' => 'id',
                    'instructions' => 'Select which FAQ groups to show on this service page.',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'custom-homes', // Will be updated with actual page IDs
                    ),
                ),
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'outdoor-spaces',
                    ),
                ),
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'pool-houses-garages-adus',
                    ),
                ),
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'sunrooms-additions',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Build Process Page Fields
     *
     * Location: Build Process page
     * Contains: Intro, process steps repeater, FAQ groups
     */
    private function register_process_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_process_fields',
            'title' => 'Build Process Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_process_intro',
                    'label' => 'Process Introduction',
                    'name' => 'gc_process_intro',
                    'type' => 'textarea',
                    'rows' => 3,
                ),
                array(
                    'key' => 'field_gc_process_steps',
                    'label' => 'Process Steps',
                    'name' => 'gc_process_steps',
                    'type' => 'repeater',
                    'layout' => 'table',
                    'button_label' => 'Add Step',
                    'sub_fields' => array(
                        array(
                            'key' => 'field_gc_process_steps__label',
                            'label' => 'Step Label',
                            'name' => 'label',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '40' ),
                        ),
                        array(
                            'key' => 'field_gc_process_steps__short_desc',
                            'label' => 'Short Description',
                            'name' => 'short_desc',
                            'type' => 'textarea',
                            'rows' => 2,
                            'wrapper' => array( 'width' => '60' ),
                        ),
                    ),
                ),
                array(
                    'key' => 'field_gc_process_faq_groups',
                    'label' => 'FAQ Groups to Display',
                    'name' => 'gc_process_faq_groups',
                    'type' => 'taxonomy',
                    'taxonomy' => 'faq_group',
                    'field_type' => 'multi_select',
                    'return_format' => 'id',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'build-process',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Team Page Fields
     *
     * Location: Team page
     * Contains: Intro, team members repeater, mission, promise
     */
    private function register_team_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_team_fields',
            'title' => 'Team Page Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_team_intro',
                    'label' => 'Team Introduction',
                    'name' => 'gc_team_intro',
                    'type' => 'textarea',
                    'rows' => 3,
                ),
                array(
                    'key' => 'field_gc_team_members',
                    'label' => 'Team Members',
                    'name' => 'gc_team_members',
                    'type' => 'repeater',
                    'layout' => 'block',
                    'button_label' => 'Add Team Member',
                    'sub_fields' => array(
                        array(
                            'key' => 'field_gc_team_members__name',
                            'label' => 'Name',
                            'name' => 'name',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_team_members__title',
                            'label' => 'Title',
                            'name' => 'title',
                            'type' => 'text',
                            'wrapper' => array( 'width' => '50' ),
                        ),
                        array(
                            'key' => 'field_gc_team_members__bio',
                            'label' => 'Bio',
                            'name' => 'bio',
                            'type' => 'textarea',
                            'rows' => 4,
                            'instructions' => '60-90 words.',
                        ),
                        array(
                            'key' => 'field_gc_team_members__photo',
                            'label' => 'Photo',
                            'name' => 'photo',
                            'type' => 'image',
                            'return_format' => 'array',
                            'preview_size' => 'medium',
                        ),
                        array(
                            'key' => 'field_gc_team_members__highlight_owner',
                            'label' => 'Highlight as Owner/Founder',
                            'name' => 'highlight_owner',
                            'type' => 'true_false',
                            'default_value' => 0,
                            'ui' => 1,
                            'instructions' => 'Display this member prominently as the owner.',
                        ),
                    ),
                ),
                array(
                    'key' => 'field_gc_team_mission',
                    'label' => 'Mission Statement',
                    'name' => 'gc_team_mission',
                    'type' => 'textarea',
                    'rows' => 4,
                ),
                array(
                    'key' => 'field_gc_team_promise',
                    'label' => 'Team Promise',
                    'name' => 'gc_team_promise',
                    'type' => 'textarea',
                    'rows' => 3,
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'our-team',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Gallery Page Fields
     *
     * Location: Gallery page
     * Contains: Intro, filter toggle
     */
    private function register_gallery_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_gallery_fields',
            'title' => 'Gallery Page Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_gallery_intro',
                    'label' => 'Gallery Introduction',
                    'name' => 'gc_gallery_intro',
                    'type' => 'textarea',
                    'rows' => 2,
                ),
                array(
                    'key' => 'field_gc_gallery_filter_enabled',
                    'label' => 'Enable Filters',
                    'name' => 'gc_gallery_filter_enabled',
                    'type' => 'true_false',
                    'default_value' => 1,
                    'ui' => 1,
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'gallery',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Contact Page Fields
     *
     * Location: Contact page
     * Contains: Intro, map embed, FAQ groups
     */
    private function register_contact_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_contact_fields',
            'title' => 'Contact Page Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_contact_intro',
                    'label' => 'Contact Introduction',
                    'name' => 'gc_contact_intro',
                    'type' => 'textarea',
                    'rows' => 2,
                ),
                array(
                    'key' => 'field_gc_contact_map_embed',
                    'label' => 'Map Embed',
                    'name' => 'gc_contact_map_embed',
                    'type' => 'oembed',
                    'instructions' => 'Paste a Google Maps embed URL.',
                ),
                array(
                    'key' => 'field_gc_contact_faq_groups',
                    'label' => 'FAQ Groups to Display',
                    'name' => 'gc_contact_faq_groups',
                    'type' => 'taxonomy',
                    'taxonomy' => 'faq_group',
                    'field_type' => 'multi_select',
                    'return_format' => 'id',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'contact',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Estimate Page Fields
     *
     * Location: Request an Estimate page
     * Contains: Reassurance copy
     */
    private function register_estimate_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_estimate_fields',
            'title' => 'Estimate Page Content',
            'fields' => array(
                array(
                    'key' => 'field_gc_estimate_reassurance_copy',
                    'label' => 'Reassurance Copy',
                    'name' => 'gc_estimate_reassurance_copy',
                    'type' => 'textarea',
                    'rows' => 3,
                    'instructions' => 'Used in both the page and the lightbox. 2-3 sentences.',
                    'default_value' => 'Tell us about your project and we will provide clear next steps, realistic timelines, and thoughtful options that match your goals and budget.',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => 'request-an-estimate',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ) );
    }

    /**
     * Project CPT Fields
     *
     * Location: Project post type
     * Contains: Location, summary, design image toggle, gallery
     */
    private function register_project_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_project_fields',
            'title' => 'Project Details',
            'fields' => array(
                array(
                    'key' => 'field_gc_project_location_city',
                    'label' => 'City',
                    'name' => 'gc_project_location_city',
                    'type' => 'text',
                    'wrapper' => array( 'width' => '50' ),
                ),
                array(
                    'key' => 'field_gc_project_location_state',
                    'label' => 'State',
                    'name' => 'gc_project_location_state',
                    'type' => 'text',
                    'default_value' => 'SC',
                    'wrapper' => array( 'width' => '50' ),
                ),
                array(
                    'key' => 'field_gc_project_short_summary',
                    'label' => 'Short Summary',
                    'name' => 'gc_project_short_summary',
                    'type' => 'textarea',
                    'rows' => 3,
                    'instructions' => 'Brief description for cards and listings.',
                ),
                array(
                    'key' => 'field_gc_project_has_design_image',
                    'label' => 'Include Design/Before Image',
                    'name' => 'gc_project_has_design_image',
                    'type' => 'true_false',
                    'default_value' => 0,
                    'ui' => 1,
                ),
                array(
                    'key' => 'field_gc_project_design_image',
                    'label' => 'Design/Before Image',
                    'name' => 'gc_project_design_image',
                    'type' => 'image',
                    'return_format' => 'array',
                    'preview_size' => 'medium',
                    'conditional_logic' => array(
                        array(
                            array(
                                'field' => 'field_gc_project_has_design_image',
                                'operator' => '==',
                                'value' => '1',
                            ),
                        ),
                    ),
                ),
                array(
                    'key' => 'field_gc_project_gallery',
                    'label' => 'Project Gallery',
                    'name' => 'gc_project_gallery',
                    'type' => 'gallery',
                    'return_format' => 'array',
                    'preview_size' => 'medium',
                ),
                array(
                    'key' => 'field_gc_project_featured_on_home',
                    'label' => 'Feature on Home Page',
                    'name' => 'gc_project_featured_on_home',
                    'type' => 'true_false',
                    'default_value' => 0,
                    'ui' => 1,
                    'instructions' => 'Quick toggle to include in home page featured projects.',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'project',
                    ),
                ),
            ),
            'position' => 'normal',
            'show_in_rest' => true,
        ) );
    }

    /**
     * FAQ CPT Fields
     *
     * Location: FAQ post type
     * Contains: Answer (title is the question)
     */
    private function register_faq_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_faq_fields',
            'title' => 'FAQ Details',
            'fields' => array(
                array(
                    'key' => 'field_gc_faq_answer',
                    'label' => 'Answer',
                    'name' => 'gc_faq_answer',
                    'type' => 'textarea',
                    'rows' => 5,
                    'instructions' => 'The post title serves as the question. Enter the answer here.',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'faq',
                    ),
                ),
            ),
            'position' => 'acf_after_title',
            'show_in_rest' => true,
        ) );
    }

    /**
     * Testimonial CPT Fields
     *
     * Location: Testimonial post type
     * Contains: Quote, first name, last initial, city, service category, project type, source
     */
    private function register_testimonial_fields() {
        acf_add_local_field_group( array(
            'key' => 'group_gc_testimonial_fields',
            'title' => 'Testimonial Details',
            'fields' => array(
                array(
                    'key' => 'field_gc_testimonial_quote',
                    'label' => 'Quote',
                    'name' => 'gc_testimonial_quote',
                    'type' => 'textarea',
                    'rows' => 4,
                    'required' => 1,
                    'instructions' => 'The testimonial text.',
                ),
                array(
                    'key' => 'field_gc_testimonial_first_name',
                    'label' => 'First Name',
                    'name' => 'gc_testimonial_first_name',
                    'type' => 'text',
                    'required' => 1,
                    'wrapper' => array( 'width' => '33' ),
                ),
                array(
                    'key' => 'field_gc_testimonial_last_initial',
                    'label' => 'Last Initial',
                    'name' => 'gc_testimonial_last_initial',
                    'type' => 'text',
                    'required' => 1,
                    'wrapper' => array( 'width' => '33' ),
                ),
                array(
                    'key' => 'field_gc_testimonial_city',
                    'label' => 'City',
                    'name' => 'gc_testimonial_city',
                    'type' => 'text',
                    'wrapper' => array( 'width' => '34' ),
                ),
                array(
                    'key' => 'field_gc_testimonial_service_category',
                    'label' => 'Service Category',
                    'name' => 'gc_testimonial_service_category',
                    'type' => 'taxonomy',
                    'taxonomy' => 'service_category',
                    'field_type' => 'select',
                    'allow_null' => 1,
                    'return_format' => 'id',
                    'instructions' => 'Optional. Link this testimonial to a service category.',
                    'wrapper' => array( 'width' => '50' ),
                ),
                array(
                    'key' => 'field_gc_testimonial_project_type',
                    'label' => 'Project Type',
                    'name' => 'gc_testimonial_project_type',
                    'type' => 'text',
                    'instructions' => 'Optional context, e.g., "Pool house build" or "Custom home".',
                    'wrapper' => array( 'width' => '50' ),
                ),
                array(
                    'key' => 'field_gc_testimonial_source',
                    'label' => 'Source',
                    'name' => 'gc_testimonial_source',
                    'type' => 'select',
                    'choices' => array(
                        'magazine' => 'Magazine',
                        'google' => 'Google',
                        'referral' => 'Referral',
                    ),
                    'default_value' => 'magazine',
                    'wrapper' => array( 'width' => '50' ),
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'testimonial',
                    ),
                ),
            ),
            'position' => 'acf_after_title',
            'show_in_rest' => true,
        ) );
    }
}
