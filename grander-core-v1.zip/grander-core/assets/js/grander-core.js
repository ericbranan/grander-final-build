/**
 * Grander Core JavaScript
 *
 * Provides mobile behaviors and small UI enhancements.
 * Does not render layouts - that's Elementor's job.
 *
 * Features:
 * - Mobile floating call icon
 * - FAQ accordion behavior
 * - Header scroll state
 * - Smooth scroll for jump links
 *
 * @package Grander_Core
 * @since 1.0.0
 */

(function() {
    'use strict';

    /**
     * Configuration from PHP
     * Available via granderCoreData global
     */
    var config = window.granderCoreData || {
        phoneNumber: '',
        phoneClean: '',
        breakpoint: 768
    };

    /**
     * Initialize when DOM is ready
     */
    document.addEventListener('DOMContentLoaded', function() {
        initMobileCallIcon();
        initFAQAccordion();
        initHeaderScroll();
        initSmoothScroll();
    });

    /**
     * Mobile Floating Call Icon
     *
     * Creates a floating phone icon fixed bottom-right on mobile.
     * Only displays when below the breakpoint and phone number is set.
     */
    function initMobileCallIcon() {
        if (!config.phoneClean) {
            return;
        }

        // Create the floating icon element
        var floatIcon = document.createElement('a');
        floatIcon.href = 'tel:' + config.phoneClean;
        floatIcon.className = 'gc-float-call';
        floatIcon.setAttribute('aria-label', 'Call us at ' + config.phoneNumber);
        floatIcon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>';

        document.body.appendChild(floatIcon);

        // The CSS handles show/hide via media query
        // This JS can add additional logic if needed
    }

    /**
     * FAQ Accordion Behavior
     *
     * Handles expand/collapse for FAQ items.
     * Looks for elements with .gc-faq-question class.
     */
    function initFAQAccordion() {
        var questions = document.querySelectorAll('.gc-faq-question');

        if (!questions.length) {
            return;
        }

        questions.forEach(function(question) {
            question.addEventListener('click', function(e) {
                e.preventDefault();

                var item = this.closest('.gc-faq-item');
                if (!item) return;

                var isOpen = item.classList.contains('gc-faq-item--open');

                // Optional: Close all other items (accordion behavior)
                var accordion = item.closest('.gc-faq-accordion-v1');
                if (accordion) {
                    var allItems = accordion.querySelectorAll('.gc-faq-item');
                    allItems.forEach(function(otherItem) {
                        if (otherItem !== item) {
                            otherItem.classList.remove('gc-faq-item--open');
                        }
                    });
                }

                // Toggle current item
                item.classList.toggle('gc-faq-item--open', !isOpen);
            });

            // Keyboard accessibility
            question.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.click();
                }
            });

            // Make focusable
            if (!question.getAttribute('tabindex')) {
                question.setAttribute('tabindex', '0');
                question.setAttribute('role', 'button');
            }
        });
    }

    /**
     * Header Scroll State
     *
     * Adds .gc-header-stripe--scrolled class when page is scrolled.
     * Useful for shadow or background changes.
     */
    function initHeaderScroll() {
        var headerStripe = document.querySelector('.gc-header-stripe');

        if (!headerStripe) {
            return;
        }

        var scrollThreshold = 50;

        function updateScrollState() {
            var scrolled = window.scrollY > scrollThreshold;
            headerStripe.classList.toggle('gc-header-stripe--scrolled', scrolled);
        }

        // Initial check
        updateScrollState();

        // Throttled scroll handler
        var ticking = false;
        window.addEventListener('scroll', function() {
            if (!ticking) {
                window.requestAnimationFrame(function() {
                    updateScrollState();
                    ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });
    }

    /**
     * Smooth Scroll for Jump Links
     *
     * Handles smooth scrolling for anchor links on service pages.
     * Only applies to links with hash that target elements on the same page.
     */
    function initSmoothScroll() {
        document.addEventListener('click', function(e) {
            var link = e.target.closest('a[href^="#"]');

            if (!link) return;

            var targetId = link.getAttribute('href');
            if (targetId === '#' || targetId.length < 2) return;

            var target = document.querySelector(targetId);
            if (!target) return;

            e.preventDefault();

            // Calculate offset for sticky header
            var headerStripe = document.querySelector('.gc-header-stripe');
            var offset = headerStripe ? headerStripe.offsetHeight + 20 : 20;

            var targetPosition = target.getBoundingClientRect().top + window.scrollY - offset;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });

            // Update URL hash without jumping
            if (history.pushState) {
                history.pushState(null, null, targetId);
            }
        });
    }

    /**
     * Utility: Debounce function
     *
     * @param {Function} func Function to debounce
     * @param {number} wait Wait time in ms
     * @returns {Function}
     */
    function debounce(func, wait) {
        var timeout;
        return function() {
            var context = this;
            var args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                func.apply(context, args);
            }, wait);
        };
    }

    /**
     * Utility: Check if on mobile
     *
     * @returns {boolean}
     */
    function isMobile() {
        return window.innerWidth < config.breakpoint;
    }

    // Expose utilities if needed
    window.granderCore = {
        isMobile: isMobile,
        debounce: debounce
    };

})();
